# QQ邮箱验证码助手 (LSPosed 模块) V1.0
目标：QQ邮箱 7.2.0 / Android 15 / Kotlin

## 构建 APK
- 电脑：Android Studio 打开本目录 → Build → Build APK(s)，或 `gradle assembleRelease`
- 无环境：把整个项目传到 GitHub，Actions 会自动构建，在 Artifacts 下载 APK

## 使用
1. 安装 APK → LSPosed 启用模块，作用域勾选「QQ邮箱」
2. 强制停止 QQ邮箱后重开；在模块界面调整设置
3. 收到/打开验证码邮件 → 顶部卡片 + 自动复制 + 通知
