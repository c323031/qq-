package com.peng.qqmailcode

import android.content.ClipData
import android.content.Context
import android.widget.Toast

object ClipboardHelper {
    fun copy(ctx: Context, code: String, toast: Boolean = true) {
        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("验证码", code))
        if (toast) Toast.makeText(ctx, "验证码 $code 已复制", Toast.LENGTH_SHORT).show()
    }
}
