package com.peng.qqmailcode

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build

object NotificationHelper {
    const val CHANNEL_ID = "qqmail_code_assistant"
    const val TAG = "qqmail_code_assistant"
    private const val ACTION_COPY = "com.peng.qqmailcode.COPY"
    private var receiverRegistered = false

    fun show(ctx: Context, code: String, sender: String?) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel(CHANNEL_ID) == null) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL_ID, "验证码提示", NotificationManager.IMPORTANCE_HIGH))
        }
        registerReceiver(ctx)
        val pi = PendingIntent.getBroadcast(
            ctx, 0, Intent(ACTION_COPY).setPackage(ctx.packageName).putExtra("code", code),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(ctx, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("验证码 $code")
            .setContentText(if (sender.isNullOrBlank()) "点击复制" else "来自 $sender · 点击复制")
            .setContentIntent(pi)
            .setAutoCancel(true)
            .setTimeoutAfter(60_000)
            .build()
        nm.notify(TAG, 1001, n)
    }

    private fun registerReceiver(ctx: Context) {
        if (receiverRegistered) return
        receiverRegistered = true
        val r = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                i.getStringExtra("code")?.let { ClipboardHelper.copy(c, it) }
            }
        }
        val f = IntentFilter(ACTION_COPY)
        if (Build.VERSION.SDK_INT >= 33) ctx.registerReceiver(r, f, Context.RECEIVER_NOT_EXPORTED)
        else ctx.registerReceiver(r, f)
    }
}
