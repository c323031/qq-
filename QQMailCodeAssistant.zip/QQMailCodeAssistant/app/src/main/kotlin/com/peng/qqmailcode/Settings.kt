package com.peng.qqmailcode

import android.content.Context
import android.content.SharedPreferences
import de.robv.android.xposed.XSharedPreferences

/** 设置项（模块界面写入，QQ邮箱进程内通过 XSharedPreferences 读取） */
object Settings {
    const val PKG = "com.peng.qqmailcode"
    const val FILE = "settings"

    const val ENABLED = "enabled"
    const val AUTO_COPY = "auto_copy"
    const val SHOW_CARD = "show_card"
    const val SHOW_NOTIFY = "show_notify"
    const val NEED_KEYWORD = "need_keyword"
    const val SHOW_SENDER = "show_sender"
    const val DEBUG_LOG = "debug_log"

    val defaults = mapOf(
        ENABLED to true, AUTO_COPY to true, SHOW_CARD to true,
        SHOW_NOTIFY to true, NEED_KEYWORD to true, SHOW_SENDER to true, DEBUG_LOG to false
    )

    private var xsp: XSharedPreferences? = null

    fun get(key: String): Boolean {
        val def = defaults[key] ?: false
        return try {
            val p = xsp ?: XSharedPreferences(PKG, FILE).also { xsp = it }
            p.reload()
            p.getBoolean(key, def)
        } catch (t: Throwable) { def }
    }

    @Suppress("DEPRECATION", "WorldReadableFiles")
    fun prefs(ctx: Context): SharedPreferences = try {
        ctx.getSharedPreferences(FILE, Context.MODE_WORLD_READABLE)
    } catch (t: Throwable) {
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
    }
}
