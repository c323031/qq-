package com.peng.qqmailcode

/** 验证码识别：关键词过滤 + 正则提取 + 误识别排除 */
object CodeExtractor {

    private val keywords = listOf(
        "验证码", "校验码", "确认码", "动态码", "动态密码", "安全码", "登录码", "认证码", "授权码", "口令",
        "verification code", "verification", "security code", "login code", "auth code",
        "one-time", "passcode", "otp", "code"
    )

    private val numeric = Regex("(?<![0-9A-Za-z.])([0-9]{4,8})(?![0-9A-Za-z]|\\.[0-9])")
    private val mixed = Regex("(?<![0-9A-Za-z])((?=[A-Za-z0-9]*[0-9])(?=[A-Za-z0-9]*[A-Za-z])[A-Za-z0-9]{5,8})(?![0-9A-Za-z])")

    private val badAfter = Regex("^\\s*(元|块|分钟|分|秒|min|minute|minutes|%|年|月|日|号|点|时|天|人|条|次|个|MB|KB|GB)", RegexOption.IGNORE_CASE)
    private val badBefore = Regex("(¥|￥|\\$|€|共|金额|余额|尾号|编号|订单号?|单号|工号|手机号?|电话)\\s*[:：]?\\s*$")

    data class Result(val code: String, val keyword: String?)
    private data class Cand(val code: String, val dist: Int, val kw: String?)

    fun extract(raw: String, needKeyword: Boolean = true): Result? {
        val text = raw.replace('\u00A0', ' ').replace(Regex("\\s+"), " ").trim()
        if (text.isEmpty()) return null

        val lower = text.lowercase()
        val kwPos = ArrayList<Pair<Int, String>>()
        for (k in keywords) {
            var i = lower.indexOf(k)
            while (i >= 0) { kwPos.add(i to k); i = lower.indexOf(k, i + k.length) }
        }
        if (kwPos.isEmpty() && needKeyword) return null

        val cands = ArrayList<Cand>()

        fun consider(m: MatchResult, isMixed: Boolean) {
            val code = m.groupValues[1]
            val start = m.range.first
            val end = m.range.last + 1
            if (badAfter.containsMatchIn(text.substring(end).take(6))) return
            if (badBefore.containsMatchIn(text.substring(maxOf(0, start - 6), start))) return
            if (!isMixed && code.length == 4 && (code.startsWith("19") || code.startsWith("20")) &&
                text.substring(end).take(1).let { it == "年" || it == "-" || it == "/" }) return
            if (start > 0 && text[start - 1] in "-/:") return
            if (end < text.length && text[end] in "-/:") return

            if (kwPos.isEmpty()) { cands.add(Cand(code, 0, null)); return }
            var best: Cand? = null
            for ((pos, kw) in kwPos) {
                val kwEnd = pos + kw.length
                val d = if (start >= kwEnd) start - kwEnd else (pos - end) + 30
                if (d in 0..80 && (best == null || d < best.dist)) best = Cand(code, d, kw)
            }
            if (best != null) cands.add(best)
        }

        numeric.findAll(text).forEach { consider(it, false) }
        if (kwPos.isNotEmpty()) mixed.findAll(text).forEach { consider(it, true) }

        val pick = cands.minByOrNull { it.dist } ?: return null
        return Result(pick.code, pick.kw)
    }

    fun htmlToText(html: String): String = html
        .replace(Regex("(?is)<(script|style|head)[^>]*>.*?</\\1>"), " ")
        .replace(Regex("(?i)<br\\s*/?>|</p>|</div>|</tr>|</li>"), " ")
        .replace(Regex("(?s)<[^>]+>"), " ")
        .replace("&nbsp;", " ").replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
        .replace("&quot;", "\"").replace("&#39;", "'")
        .replace(Regex("&#(\\d+);")) { r -> r.groupValues[1].toIntOrNull()?.toChar()?.toString() ?: "" }
        .replace(Regex("\\s+"), " ")
}
