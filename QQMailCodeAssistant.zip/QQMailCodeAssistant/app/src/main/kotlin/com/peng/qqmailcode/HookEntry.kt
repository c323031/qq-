package com.peng.qqmailcode

import android.app.Activity
import android.app.Application
import android.app.Notification
import android.os.Bundle
import android.webkit.WebView
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage

/**
 * 入口。目标：QQ 邮箱 (com.tencent.androidqqmail) 7.2.0
 *
 * 不依赖混淆后的类名，使用两条通用识别路径：
 *  1. NotificationManager.notify —— 新邮件通知（标题/正文含验证码）
 *  2. WebView.loadDataWithBaseURL / loadData —— 打开邮件正文（HTML）
 * 若要更精确，可在反编译 7.2.0 后针对邮件解析类补充精确 Hook。
 */
class HookEntry : IXposedHookLoadPackage {

    companion object {
        const val TARGET = "com.tencent.androidqqmail"
        @Volatile var app: Application? = null
        @Volatile var topActivity: Activity? = null
        private var lastCode = ""
        private var lastTime = 0L

        fun log(msg: String) {
            if (Settings.get(Settings.DEBUG_LOG)) XposedBridge.log("[QQMailCode] $msg")
        }

        @Synchronized
        fun handleText(text: String?, sender: String?, source: String) {
            if (text.isNullOrBlank() || !Settings.get(Settings.ENABLED)) return
            val r = CodeExtractor.extract(text, Settings.get(Settings.NEED_KEYWORD)) ?: return
            val now = System.currentTimeMillis()
            if (r.code == lastCode && now - lastTime < 60_000) return
            lastCode = r.code; lastTime = now
            log("[$source] code=${r.code} kw=${r.keyword}")

            val ctx = app ?: return
            val who = if (Settings.get(Settings.SHOW_SENDER)) sender else null
            if (Settings.get(Settings.AUTO_COPY)) {
                android.os.Handler(android.os.Looper.getMainLooper()).post { ClipboardHelper.copy(ctx, r.code) }
            }
            if (Settings.get(Settings.SHOW_CARD)) topActivity?.let { CodeCard.show(it, r.code, who) }
            if (Settings.get(Settings.SHOW_NOTIFY)) {
                try { NotificationHelper.show(ctx, r.code, who) } catch (t: Throwable) { log("notify fail: $t") }
            }
        }
    }

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (lpparam.packageName != TARGET) return

        XposedHelpers.findAndHookMethod(Application::class.java, "onCreate", object : XC_MethodHook() {
            override fun afterHookedMethod(p: MethodHookParam) {
                if (app != null) return
                val a = p.thisObject as Application
                app = a
                a.registerActivityLifecycleCallbacks(object : Application.ActivityLifecycleCallbacks {
                    override fun onActivityResumed(activity: Activity) { topActivity = activity }
                    override fun onActivityPaused(activity: Activity) { if (topActivity === activity) topActivity = null }
                    override fun onActivityCreated(a: Activity, s: Bundle?) {}
                    override fun onActivityStarted(a: Activity) {}
                    override fun onActivityStopped(a: Activity) {}
                    override fun onActivitySaveInstanceState(a: Activity, s: Bundle) {}
                    override fun onActivityDestroyed(a: Activity) {}
                })
                log("loaded in ${lpparam.processName}")
            }
        })

        hookNotifications()
        hookWebView()
    }

    private fun hookNotifications() {
        val hook = object : XC_MethodHook() {
            override fun beforeHookedMethod(p: MethodHookParam) {
                try {
                    val n = p.args.firstOrNull { it is Notification } as? Notification ?: return
                    val tag = p.args.firstOrNull { it is String } as? String
                    if (tag == NotificationHelper.TAG) return
                    val ex = n.extras ?: return
                    val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString()
                    val body = listOfNotNull(
                        ex.getCharSequence(Notification.EXTRA_TEXT),
                        ex.getCharSequence(Notification.EXTRA_BIG_TEXT),
                        ex.getCharSequence(Notification.EXTRA_SUB_TEXT)
                    ).joinToString(" ")
                    handleText("$title $body", title, "notify")
                } catch (t: Throwable) { log("notify hook: $t") }
            }
        }
        XposedBridge.hookAllMethods(android.app.NotificationManager::class.java, "notify", hook)
    }

    private fun hookWebView() {
        XposedBridge.hookAllMethods(WebView::class.java, "loadDataWithBaseURL", object : XC_MethodHook() {
            override fun beforeHookedMethod(p: MethodHookParam) {
                try {
                    val html = p.args.getOrNull(1) as? String ?: return
                    if (html.length > 200_000) return
                    handleText(CodeExtractor.htmlToText(html), null, "webview")
                } catch (t: Throwable) { log("webview hook: $t") }
            }
        })
        XposedBridge.hookAllMethods(WebView::class.java, "loadData", object : XC_MethodHook() {
            override fun beforeHookedMethod(p: MethodHookParam) {
                try {
                    val html = p.args.getOrNull(0) as? String ?: return
                    handleText(CodeExtractor.htmlToText(html), null, "webview")
                } catch (t: Throwable) { log("webview hook: $t") }
            }
        })
    }
}
