package com.peng.qqmailcode

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/** 悬浮在当前页面顶部的验证码卡片（挂在 DecorView 上，无需悬浮窗权限） */
object CodeCard {
    private val main = Handler(Looper.getMainLooper())
    private var current: View? = null

    private fun dp(a: Activity, v: Int) = (v * a.resources.displayMetrics.density).toInt()

    fun show(a: Activity, code: String, sender: String?) {
        main.post {
            removeNow()
            val root = a.window.decorView as? ViewGroup ?: return@post

            val card = LinearLayout(a).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(a, 16), dp(a, 12), dp(a, 12), dp(a, 12))
                background = GradientDrawable().apply {
                    setColor(Color.WHITE); cornerRadius = dp(a, 16).toFloat()
                    setStroke(dp(a, 1), Color.parseColor("#E0E0E0"))
                }
                elevation = dp(a, 8).toFloat()
            }
            val col = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
            col.addView(TextView(a).apply {
                text = if (sender.isNullOrBlank()) "QQ邮箱验证码" else "QQ邮箱验证码 · $sender"
                textSize = 12f; setTextColor(Color.GRAY)
            })
            col.addView(TextView(a).apply {
                text = code; textSize = 28f; typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.parseColor("#1A73E8")); letterSpacing = 0.1f
            })
            card.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            card.addView(TextView(a).apply {
                text = "复制"; setTextColor(Color.WHITE); textSize = 14f; gravity = Gravity.CENTER
                setPadding(dp(a, 18), dp(a, 8), dp(a, 18), dp(a, 8))
                background = GradientDrawable().apply { setColor(Color.parseColor("#1A73E8")); cornerRadius = dp(a, 20).toFloat() }
                setOnClickListener { ClipboardHelper.copy(a, code); removeNow() }
            })

            @Suppress("DEPRECATION")
            val inset = root.rootWindowInsets?.systemWindowInsetTop ?: 0
            val lp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                gravity = Gravity.TOP
                setMargins(dp(a, 12), inset + dp(a, 12), dp(a, 12), 0)
            }
            root.addView(card, lp)
            current = card
            main.postDelayed({ removeNow() }, 10_000)
        }
    }

    private fun removeNow() {
        current?.let { (it.parent as? ViewGroup)?.removeView(it) }
        current = null
    }
}
