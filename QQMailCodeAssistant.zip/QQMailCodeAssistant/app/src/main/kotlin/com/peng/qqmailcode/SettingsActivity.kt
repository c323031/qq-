package com.peng.qqmailcode

import android.app.Activity
import android.os.Bundle
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView

class SettingsActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "QQ邮箱验证码助手"
        val sp = Settings.prefs(this)
        val d = (16 * resources.displayMetrics.density).toInt()

        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(d, d, d, d) }
        box.addView(TextView(this).apply {
            text = "在 LSPosed 中启用本模块并勾选「QQ邮箱」，然后强制停止 QQ 邮箱后重新打开。"
            textSize = 13f; setPadding(0, 0, 0, d)
        })

        fun row(label: String, key: String) {
            box.addView(Switch(this).apply {
                text = label; textSize = 16f
                isChecked = sp.getBoolean(key, Settings.defaults[key] ?: false)
                setPadding(0, d / 2, 0, d / 2)
                setOnCheckedChangeListener { _, v -> sp.edit().putBoolean(key, v).apply() }
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        row("启用验证码识别", Settings.ENABLED)
        row("自动复制到剪贴板", Settings.AUTO_COPY)
        row("显示悬浮卡片", Settings.SHOW_CARD)
        row("显示通知栏提示", Settings.SHOW_NOTIFY)
        row("仅识别含关键词的邮件", Settings.NEED_KEYWORD)
        row("显示发件人", Settings.SHOW_SENDER)
        row("调试日志（LSPosed 日志）", Settings.DEBUG_LOG)

        setContentView(ScrollView(this).apply { addView(box) })
    }
}
