package com.peng.qqmailcode

import android.app.Activity
import android.app.Application
import android.app.Notification
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage
import java.lang.reflect.Proxy

/**
 * V1.1 目标：QQ 邮箱 (com.tencent.androidqqmail)
 * 识别路径（不依赖混淆类名）：
 *  1. NotificationManager.notify  —— 新邮件通知
 *  2. 系统 WebView / 腾讯 X5 WebView：loadData*、onPageFinished 后读取页面文字
 *  3. TextView.setText —— 原生控件显示的文字
 */
class HookEntry : IXposedHookLoadPackage {

    companion object {
        const val TARGET = "com.tencent.androidqqmail"
        @Volatile var app: Application? = null
        @Volatile var topActivity: Activity? = null
        private var lastCode = ""
        private var lastTime = 0L
        private var toasted = false
        private val hookedClients = java.util.Collections.synchronizedSet(HashSet<Class<*>>())

        fun log(msg: String) = XposedBridge.log("[QQMailCode] $msg")

        @Synchronized
        fun handleText(text: String?, sender: String?, source: String) {
            if (text.isNullOrBlank()) return
            val r = CodeExtractor.extract(text, Settings.get(Settings.NEED_KEYWORD))
            if (r == null) return
            if (!Settings.get(Settings.ENABLED)) return
            val now = System.currentTimeMillis()
            if (r.code == lastCode && now - lastTime < 60_000) return
            lastCode = r.code; lastTime = now
            log("[$source] code=${r.code} kw=${r.keyword}")

            val ctx = app ?: return
            val who = if (Settings.get(Settings.SHOW_SENDER)) sender else null
            if (Settings.get(Settings.AUTO_COPY)) {
                android.os.Handler(android.os.Looper.getMainLooper()).post { ClipboardHelper.copy(ctx, r.code) }
            }
            if (Settings.get(Settings.SHOW_CARD)) topActivity?.let { CodeCard.show(it, r.code, who) }
            if (Settings.get(Settings.SHOW_NOTIFY)) {
                try { NotificationHelper.show(ctx, r.code, who) } catch (t: Throwable) { log("notify fail: $t") }
            }
        }
    }

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (lpparam.packageName != TARGET) return
        log("handleLoadPackage ${lpparam.processName}")

        XposedHelpers.findAndHookMethod(Application::class.java, "onCreate", object : XC_MethodHook() {
            override fun afterHookedMethod(p: MethodHookParam) {
                if (app != null) return
                val a = p.thisObject as Application
                app = a
                a.registerActivityLifecycleCallbacks(object : Application.ActivityLifecycleCallbacks {
                    override fun onActivityResumed(activity: Activity) {
                        topActivity = activity
                        if (!toasted && lpparam.processName == TARGET) {
                            toasted = true
                            Toast.makeText(activity, "验证码助手已生效", Toast.LENGTH_SHORT).show()
                        }
                    }
                    override fun onActivityPaused(activity: Activity) { if (topActivity === activity) topActivity = null }
                    override fun onActivityCreated(a: Activity, s: Bundle?) {}
                    override fun onActivityStarted(a: Activity) {}
                    override fun onActivityStopped(a: Activity) {}
                    override fun onActivitySaveInstanceState(a: Activity, s: Bundle) {}
                    override fun onActivityDestroyed(a: Activity) {}
                })
            }
        })

        safe("notifications") { hookNotifications() }
        safe("webview") { hookWebViews(lpparam.classLoader) }
        safe("textview") { hookTextView() }
    }

    private fun safe(name: String, block: () -> Unit) {
        try { block(); log("hook ok: $name") } catch (t: Throwable) { log("hook FAIL $name: $t") }
    }

    private fun hookNotifications() {
        val hook = object : XC_MethodHook() {
            override fun beforeHookedMethod(p: MethodHookParam) {
                try {
                    val n = p.args.firstOrNull { it is Notification } as? Notification ?: return
                    val tag = p.args.firstOrNull { it is String } as? String
                    if (tag == NotificationHelper.TAG) return
                    val ex = n.extras
                    val title = ex?.getCharSequence(Notification.EXTRA_TITLE)?.toString()
                    val parts = ArrayList<String>()
                    parts.add(title ?: "")
                    n.tickerText?.let { parts.add(it.toString()) }
                    ex?.getCharSequence(Notification.EXTRA_TEXT)?.let { parts.add(it.toString()) }
                    ex?.getCharSequence(Notification.EXTRA_BIG_TEXT)?.let { parts.add(it.toString()) }
                    ex?.getCharSequence(Notification.EXTRA_SUB_TEXT)?.let { parts.add(it.toString()) }
                    ex?.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)?.forEach { parts.add(it.toString()) }
                    val all = parts.joinToString(" ")
                    log("notify: $all")
                    handleText(all, title, "notify")
                } catch (t: Throwable) { log("notify hook: $t") }
            }
        }
        XposedBridge.hookAllMethods(android.app.NotificationManager::class.java, "notify", hook)
    }

    private fun hookWebViews(cl: ClassLoader) {
        for (name in listOf("android.webkit.WebView", "com.tencent.xweb.WebView", "com.tencent.smtt.sdk.WebView", "org.xwalk.core.XWalkView")) {
            val c = XposedHelpers.findClassIfExists(name, cl) ?: continue
            log("webview class: $name")

            XposedBridge.hookAllMethods(c, "loadDataWithBaseURL", object : XC_MethodHook() {
                override fun beforeHookedMethod(p: MethodHookParam) {
                    val html = p.args.getOrNull(1) as? String ?: return
                    if (html.length < 300_000) handleText(CodeExtractor.htmlToText(html), null, "webview-data")
                }
            })
            XposedBridge.hookAllMethods(c, "loadData", object : XC_MethodHook() {
                override fun beforeHookedMethod(p: MethodHookParam) {
                    val html = p.args.getOrNull(0) as? String ?: return
                    if (html.length < 300_000) handleText(CodeExtractor.htmlToText(html), null, "webview-data")
                }
            })
            // 拿到 WebViewClient 后，Hook 它的 onPageFinished，页面加载完读取正文
            XposedBridge.hookAllMethods(c, "setWebViewClient", object : XC_MethodHook() {
                override fun afterHookedMethod(p: MethodHookParam) {
                    val client = p.args.getOrNull(0) ?: return
                    hookClient(client.javaClass)
                }
            })
        }
    }

    private fun hookClient(cls: Class<*>) {
        if (!hookedClients.add(cls)) return
        XposedBridge.hookAllMethods(cls, "onPageFinished", object : XC_MethodHook() {
            override fun afterHookedMethod(p: MethodHookParam) {
                val view = p.args.getOrNull(0) ?: return
                readPage(view)
            }
        })
        log("hooked client ${cls.name}")
    }

    /** 通过 evaluateJavascript 读取页面文字（兼容系统 WebView 和 X5，回调类型用动态代理） */
    private fun readPage(view: Any) {
        try {
            val m = view.javaClass.methods.firstOrNull {
                it.name == "evaluateJavascript" && it.parameterTypes.size == 2
            } ?: return
            val cbType = m.parameterTypes[1]
            val cb = Proxy.newProxyInstance(cbType.classLoader, arrayOf(cbType)) { _, method, args ->
                if (method.name == "onReceiveValue") {
                    val s = (args?.getOrNull(0) as? String)?.let { unquote(it) }
                    handleText(s, null, "webview-js")
                }
                null
            }
            m.invoke(view, "(function(){return document.body?document.body.innerText:''})()", cb)
        } catch (t: Throwable) { log("readPage: $t") }
    }

    private fun unquote(s: String): String {
        var t = s
        if (t.length >= 2 && t.startsWith("\"") && t.endsWith("\"")) t = t.substring(1, t.length - 1)
        return t.replace("\\n", " ").replace("\\t", " ").replace("\\\"", "\"")
            .replace(Regex("\\\\u([0-9a-fA-F]{4})")) { it.groupValues[1].toInt(16).toChar().toString() }
    }

    private fun hookTextView() {
        XposedBridge.hookAllMethods(TextView::class.java, "setText", object : XC_MethodHook() {
            override fun afterHookedMethod(p: MethodHookParam) {
                val t = p.args.getOrNull(0) as? CharSequence ?: return
                if (t.length !in 6..1500) return
                val s = t.toString()
                if (!(s.contains("码") || s.contains("code", true) || s.contains("otp", true))) return
                handleText(s, null, "textview")
            }
        })
    }
}
